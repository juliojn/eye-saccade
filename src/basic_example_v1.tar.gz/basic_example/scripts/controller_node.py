#!/usr/bin/python3.7
from std_msgs.msg import String
from basic_example.srv import *
import rospy
import sys
import os

def getErrorClient(req):
	rospy.wait_for_service("get_error")
	try:
		get_error = rospy.ServiceProxy('get_error', GetError)
		response = get_error(req.current_pos, req.time)
		return response.error
	except rospy.ServiceException as e:
		print("Service call failed: %s"%e)

def get_control_signal_handler(req):
	print("[%s, %s]"%(req.current_pos, req.time))
	# if (req.time < 0.5):
	# 	return GetControlSignalResponse(0.0, 1.0)
	# else:
	# 	return GetControlSignalResponse(0.0, 0.0)
	error = getErrorClient(req)
	if error > 0.0:
		return GetControlSignalResponse(0.0, 1.0)
	else:
		return GetControlSignalResponse(1.0, 0.0)
	# print("[%s, %s]"%(lateral_control, lateral_control))
	# print(lateral_control)

def get_control_signal():
	rospy.init_node("get_control_signal")
	s = rospy.Service("get_control_signal", GetControlSignal, get_control_signal_handler)
	rospy.spin()


if __name__ == "__main__":
	get_control_signal()
