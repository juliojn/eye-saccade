#!/usr/bin/python3.7
from std_msgs.msg import String
import opensim as osim
from basic_example.srv import GetControlSignal, GetControlSignalResponse, GetError
import rospy
import sys
import os

def get_control_signal_handler(req):
	print("[%s, %s]"%(req.current_pos, req.time))
	# if (req.time < 0.5):
	# 	return GetControlSignalResponse(0.0, 1.0)
	# else:
	# 	return GetControlSignalResponse(0.0, 0.0)
	error = GetError(req.current_pos, req.time)
	if error > 0:
		lateral_signal = error / 1,396264
		medial_signal  = 0
	else:
		lateral_signal = 0
		medial_signal  = error / 1,396264

	return GetControlSignalResponse(lateral_signal, medial_signal)

def get_control_signal():
	rospy.init_node("get_control_signal")
	s = rospy.Service("get_control_signal", GetControlSignal, get_control_signal_handler)
	rospy.spin()


if __name__ == "__main__":
	get_control_signal()
