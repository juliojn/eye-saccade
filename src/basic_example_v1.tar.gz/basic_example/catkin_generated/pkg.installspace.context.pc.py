# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "${prefix}/include".split(';') if "${prefix}/include" != "" else []
PROJECT_CATKIN_DEPENDS = "rospy;std_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lbasic_example".split(';') if "-lbasic_example" != "" else []
PROJECT_NAME = "basic_example"
PROJECT_SPACE_DIR = "/home/juliojn/Documentos/TFM/install"
PROJECT_VERSION = "1.0.0"
